
public class Hero1 {
	protected String name;
	protected String weapon;
	protected int health;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getWeapon() {
		return weapon;
	}
	public void setWeapon(String weapon) {
		this.weapon = weapon;
	}
	public int getHealth() {
		return health;
	}
	public void setHealth(int health) {
		this.health = health;
	}
	public Hero1(String name, String weapon, int health) {
		super();
		this.name = name;
		this.weapon = weapon;
		this.health = health;
	}
	
	public void damageBySword() {
		this.health -= 30;
		if (this.health <=0) {
			this.health = 0;
		}
		System.out.println("Life Enemy berkurang 30, new health = " +this.health);
		if (this.health == 0) {
			System.out.println(getName()+ " is Dead");
		}
	}
	
	public void damageByArrow() {
		this.health -= 25;
		if (this.health <=0) {
			this.health = 0;
		}
		System.out.println("Life Enemy berkurang 25, new health = " +this.health);
		if (this.health == 0) {
			System.out.println(getName()+ "is Dead");
		}
	}
	
	public void damageByEnemy() {
		this.health -= 40;
		if (this.health <=0) {
			this.health = 0;
		}
		System.out.println("Life Alucard berkurang 25, new health = " +this.health);
		if (this.health == 0) {
			System.out.println(getName()+ "is Dead");
		}
	}
	
	public void heal() {
		if (this.health == 0) {
			System.out.println("Your Hero is Dead, Can not Heal anymore !");
		}
		else if (this.health >= 100) {
			System.out.println("Your Hero life is full, Can not Heal anymore ! ");
		}
		else {
			this.health += 65;
			System.out.println("Life Alucard bertambah 65, new health = " +this.health);
		}
	}
	
}
