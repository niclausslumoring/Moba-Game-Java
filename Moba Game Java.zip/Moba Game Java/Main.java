import java.util.Scanner;
import java.util.Vector;

public class Main {
	Scanner scan = new Scanner(System.in);
	
	public void MenuAwal() {
		System.out.println("Choose your hero");
		System.out.println("=============================");
		System.out.println("1. Alucard [Attack : 25]");
		System.out.println("2. Miya [Attack : 30]");
		System.out.println("Choose : ");
	}
	
	public void Menu() {
		System.out.println("Fight");
		System.out.println("=============================");
		System.out.println("1. Attack");
		System.out.println("2. Rest");
		System.out.println("3. Exit");
		System.out.println("Choose : ");
	}
	public Main() {
		Hero1 hero1 = new Hero1("Alucard", "Sword", 100);
		Hero2 hero2= new Hero2("Miya", "Arrow", 100);
		Enemy enemy = new Enemy("Enemy", 100);
		
		int choiseMenuAwal = -1;
		int choiseMenu = -1;
		
		while(true) {
			MenuAwal();
			choiseMenuAwal = scan.nextInt();
			scan.nextLine();
			
			if (choiseMenuAwal == 1) {
				System.out.println(hero1.name + " " + hero1.health);
				System.out.println(enemy.name + " " + enemy.health);
				while(true) {
					Menu();
					choiseMenu = scan.nextInt();
					scan.nextLine();
					if (choiseMenu == 1) {
						hero1.damageByEnemy();
						enemy.damageBySword();
					}
					else if (choiseMenu == 2) {
						hero1.heal();
					}
					else {
						break;
					}
				}
				
			}
			else if (choiseMenuAwal == 2) {
				System.out.println(hero2.name + " " + hero2.health);
				System.out.println(enemy.name + " " + enemy.health);
				while(true) {
					Menu();
					choiseMenu = scan.nextInt();
					scan.nextLine();
					if (choiseMenu == 1) {
						hero2.damageByEnemy();
						enemy.damageByArrow();
					}
					else if (choiseMenu == 2) {
						hero2.heal();
					}
					else {
						break;
					}
				}
			}
			else {
				continue;
			}
		}
	}

	public static void main(String[] args) {
		new Main();
	}

}
