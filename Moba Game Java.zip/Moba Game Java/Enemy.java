
public class Enemy {
	protected String name;
	protected int health;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getHealth() {
		return health;
	}
	public void setHealth(int health) {
		this.health = health;
	}
	public Enemy(String name, int health) {
		super();
		this.name = name;
		this.health = health;
	}
	
	public void damageBySword() {
		this.health -= 30;
		if (this.health <=0) {
			this.health = 0;
		}
		System.out.println("Life Enemy berkurang 30, new health = " +this.health);
		if (this.health == 0) {
			System.out.println(getName()+ " is Dead");
		}
	}
	
	public void damageByArrow() {
		this.health -= 25;
		if (this.health <=0) {
			this.health = 0;
		}
		System.out.println("Life Enemy berkurang 25, new health = " +this.health);
		if (this.health == 0) {
			System.out.println(getName()+ "is Dead");
		}
	}
	
}
